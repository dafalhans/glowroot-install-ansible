# Ansible Collection - havan.glowroot

Documentation for the collection.

My attempt to learn Ansible collections, using https://github.com/olo-dw/ansible-role-glowroot as Ansible Role example 